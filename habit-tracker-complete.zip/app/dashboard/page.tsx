'use client';
import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/lib/supabase';
import HabitList from '@/components/HabitList';
import ProgressChart from '@/components/ProgressChart';
import AITips from '@/components/AITips';

export default function Dashboard() {
  const { user, signOut } = useAuth();
  const [goals, setGoals] = useState<any[]>([]);
  const [habits, setHabits] = useState<any[]>([]);

  useEffect(() => {
    if (user) fetchData();
  }, [user]);

  const fetchData = async () => {
    const { data: g } = await supabase.from('goals').select('*').eq('user_id', user!.id);
    const { data: h } = await supabase.from('habits').select(\`
      *, 
      goals(title),
      habit_logs (date, completed)
    \`).eq('user_id', user!.id);
    setGoals(g || []);
    setHabits(h || []);
  };

  if (!user) return <p className="text-center mt-20">Loading...</p>;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-pink-50">
      <header className="bg-white/60 backdrop-blur-md shadow-sm sticky top-0 z-50 p-6">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            HabitForge Dashboard
          </h1>
          <div className="flex space-x-4">
            <span className="text-sm text-gray-600">Hi, {user.email}</span>
            <button onClick={signOut} className="px-6 py-2 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all">Logout</button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-6 space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h2 className="text-2xl font-bold mb-6">Today\'s Habits</h2>
            <HabitList habits={habits} userId={user.id} onUpdate={fetchData} />
          </div>
          <div>
            <ProgressChart habits={habits} />
            <AITips habits={habits} />
          </div>
        </div>
        <div>
          <h2 className="text-2xl font-bold mb-6">Goals</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {goals.map((goal) => (
              <div key={goal.id} className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all hover:-translate-y-2 border border-gray-100">
                <h3 className="text-xl font-bold mb-2">{goal.title}</h3>
                <p className="text-gray-600 mb-4">{goal.description}</p>
                <span className="inline-block px-4 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                  Target: {new Date(goal.target_date).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
